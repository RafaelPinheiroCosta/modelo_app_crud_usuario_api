package com.rafaelcosta.modelo_app_crud_usuario_api.data.repository

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import androidx.core.net.toUri
import com.google.gson.Gson
import com.rafaelcosta.modelo_app_crud_usuario_api.data.local.dao.UsuarioDao
import com.rafaelcosta.modelo_app_crud_usuario_api.data.local.entity.UsuarioEntity
import com.rafaelcosta.modelo_app_crud_usuario_api.data.mapper.toDomain
import com.rafaelcosta.modelo_app_crud_usuario_api.data.mapper.toEntity
import com.rafaelcosta.modelo_app_crud_usuario_api.data.remote.UsuarioApi
import com.rafaelcosta.modelo_app_crud_usuario_api.di.IoDispatcher
import com.rafaelcosta.modelo_app_crud_usuario_api.domain.model.Usuario
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UsuarioRepository @Inject constructor(
    private val api: UsuarioApi,
    private val dao: UsuarioDao,
    @IoDispatcher private val io: CoroutineDispatcher,
    @ApplicationContext private val context: Context,
    private val gson: Gson
) {

    private val jsonMedia = "application/json".toMediaType()

    private fun partJsonDados(dados: Any): RequestBody =
        gson.toJson(dados).toRequestBody(jsonMedia)

    private fun partFromUri(fieldName: String, uri: Uri?): MultipartBody.Part? {
        if (uri == null) return null
        val cr: ContentResolver = context.contentResolver
        val type = cr.getType(uri) ?: "application/octet-stream"
        val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "arquivo"
        val input = cr.openInputStream(uri) ?: return null
        val tmp = File.createTempFile("up_", "_tmp", context.cacheDir)
        tmp.outputStream().use { out -> input.copyTo(out) }
        val body = tmp.asRequestBody(type.toMediaTypeOrNull())
        return MultipartBody.Part.createFormData(fieldName, fileName, body)
    }

    private fun partsFromUris(uris: List<Uri>?): List<MultipartBody.Part>? {
        if (uris.isNullOrEmpty()) return null
        return uris.mapNotNull { partFromUri("anexos", it) }
    }

    fun observeUsuarios(): Flow<List<Usuario>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    fun observeUsuario(id: String): Flow<Usuario?> =
        dao.observeById(id).map { it?.toDomain() }

    suspend fun refresh(): Result<Unit> = runCatching {
        val remote = api.list()
        dao.upsertAll(remote.map { it.toEntity(pending = false) })
    }

    suspend fun create(
        nome: String,
        email: String,
        cpf: String,
        senha: String,
        fotoUri: Uri?,
        anexosUris: List<Uri>?
    ): Usuario {
        return withContext(io) {

            val tempId = "local-${System.currentTimeMillis()}"
            val localUsuario = UsuarioEntity(
                id = tempId,
                nome = nome,
                email = email,
                cpf = cpf,
                senha = senha,
                fotoPerfilUrl = fotoUri?.toString(),
                anexos = anexosUris?.map { it.toString() },
                updatedAt = System.currentTimeMillis(),
                pendingSync = true,
                localOnly = true
            )

            dao.upsert(localUsuario)

            runCatching {
                val dados = mapOf("nome" to nome, "email" to email, "cpf" to cpf, "senha" to senha)

                val resp = api.create(
                    dadosJson = partJsonDados(dados),
                    foto = partFromUri("foto", fotoUri),
                    anexos = partsFromUris(anexosUris)
                )

                dao.deleteById(tempId)
                dao.upsert(resp.toEntity(pending = false))

                resp.toDomain()
            }.getOrElse {
                localUsuario.toDomain()
            }
        }
    }

    suspend fun update(
        id: String,
        nome: String,
        email: String,
        cpf: String,
        senha: String?,
        fotoUri: Uri?,
        anexosUris: List<Uri>?
    ): Usuario {
        return withContext(io) {
            val local = dao.getById(id) ?: throw IllegalArgumentException("Usuário não encontrado")
            val updated = local.copy(
                nome = nome,
                email = email,
                cpf = cpf,
                senha = senha ?: local.senha,
                fotoPerfilUrl = fotoUri?.toString() ?: local.fotoPerfilUrl,
                anexos = anexosUris?.map { it.toString() } ?: local.anexos,
                updatedAt = System.currentTimeMillis(),
                pendingSync = true
            )

            dao.upsert(updated)

            runCatching {
                val dados = buildMap<String, Any> {
                    put("nome", nome)
                    put("email", email)
                    put("cpf", cpf)
                    senha?.takeIf { it.isNotBlank() }?.let { put("senha", it) }
                }

                val resp = api.update(
                    id = id,
                    dadosJson = partJsonDados(dados),
                    foto = partFromUri("foto", fotoUri),
                    anexos = partsFromUris(anexosUris)
                )

                dao.upsert(resp.toEntity(pending = false))
                resp.toDomain()
            }.getOrElse {
                updated.toDomain()
            }
        }
    }


    suspend fun delete(id: String): Result<Unit> = runCatching {
        val local = dao.getById(id)
        if (local != null) {

            dao.upsert(local.copy(pendingSync = true))
        }

        runCatching { api.delete(id) }
            .onSuccess {

                dao.deleteById(id)
            }
            .onFailure {

            }
    }

    suspend fun sincronizarUsuarios() {

        val pendentes = dao.getPendingSync()
        for (usuario in pendentes) {
            try {
                val dados = buildMap<String, Any> {
                    put("nome", usuario.nome)
                    put("email", usuario.email)
                    put("cpf", usuario.cpf)
                    usuario.senha?.takeIf { it.isNotBlank() }?.let { put("senha", it) }
                }

                val fotoUri = usuario.fotoPerfilUrl?.toUri()
                val anexosUris =
                    usuario.anexos?.mapNotNull { runCatching { it.toUri() }.getOrNull() }

                when (usuario.operationType) {
                    "UPDATE" -> {
                        val resp = api.update(
                            id = usuario.id,
                            dadosJson = partJsonDados(dados),
                            foto = partFromUri("foto", fotoUri),
                            anexos = partsFromUris(anexosUris)
                        )
                        dao.upsert(resp.toEntity(pending = false))
                    }

                    "DELETE" -> {
                        api.delete(usuario.id)
                        dao.deleteById(usuario.id)
                    }

                    else -> {
                        val resp = api.create(
                            dadosJson = partJsonDados(dados),
                            foto = partFromUri("foto", fotoUri),
                            anexos = partsFromUris(anexosUris)
                        )
                        dao.deleteById(usuario.id)
                        dao.upsert(resp.toEntity(pending = false))
                    }
                }
            } catch (_: Exception) {

            }
        }

        try {
            val listaApi = api.list()

            val remotos = listaApi.map { it.toEntity(pending = false) }

            dao.upsertAll(remotos)

            val idsRemotos = remotos.map { it.id }.toSet()

            val locais = dao.getAll() // método seguro (veja abaixo)
            val paraRemover =
                locais.filter { !idsRemotos.contains(it.id) && !it.pendingSync && !it.localOnly }

            paraRemover.forEach { dao.deleteById(it.id) }

        } catch (e: Exception) {
            android.util.Log.w(
                "UsuarioRepository",
                "⚠️ Sem conexão — não foi possível atualizar da API (${e.message})"
            )
        }


    }

    @Suppress("unused")
    suspend fun syncAll(): Result<Unit> = runCatching {
        val pendentes = dao.getPendingSync()

        for (e in pendentes) {
            try {
                if (e.localOnly) {
                    // Criar no servidor
                    val dados = mapOf(
                        "nome" to e.nome,
                        "email" to e.email,
                        "cpf" to e.cpf,
                        "senha" to e.senha
                    )
                    val resp = api.create(
                        dadosJson = partJsonDados(dados),
                        foto = partFromUri("foto", e.fotoPerfilUrl?.toUri()),
                        anexos = partsFromUris(e.anexos?.map { it.toUri() })
                    )
                    dao.deleteById(e.id)
                    dao.upsert(resp.toEntity(pending = false))
                } else {
                    // Atualizar no servidor
                    val dados = buildMap<String, Any> {
                        put("nome", e.nome)
                        put("email", e.email)
                        put("cpf", e.cpf)
                        e.senha?.let { put("senha", it) }
                    }
                    val resp = api.update(
                        id = e.id,
                        dadosJson = partJsonDados(dados),
                        foto = partFromUri("foto", e.fotoPerfilUrl?.toUri()),
                        anexos = partsFromUris(e.anexos?.map { it.toUri() })
                    )
                    dao.upsert(resp.toEntity(pending = false))
                }
            } catch (_: Exception) {
                // mantém pendingSync = true
            }
        }

        refresh()
    }

    @Suppress("unused")
    private suspend fun tryPushOne(id: String) {
        val e = dao.getById(id) ?: return

        // monta o JSON do corpo
        val dados = buildMap<String, Any> {
            put("nome", e.nome)
            put("email", e.email)
            put("cpf", e.cpf)
            e.senha?.takeIf { it.isNotBlank() }?.let { put("senha", it) }
        }

        val fotoUri = e.fotoPerfilUrl?.toUri()
        val anexosUris = e.anexos?.mapNotNull { runCatching { it.toUri() }.getOrNull() }

        val pushed = if (existsRemote(id)) {
            api.update(
                id = id,
                dadosJson = partJsonDados(dados),
                foto = partFromUri("foto", fotoUri),
                anexos = partsFromUris(anexosUris)
            )
        } else {
            api.create(
                dadosJson = partJsonDados(dados),
                foto = partFromUri("foto", fotoUri),
                anexos = partsFromUris(anexosUris)
            )
        }

        dao.upsert(pushed.toEntity(pending = false).copy(senha = null))
    }

    private suspend fun existsRemote(id: String): Boolean = runCatching {
        api.get(id); true
    }.getOrDefault(false)
}
