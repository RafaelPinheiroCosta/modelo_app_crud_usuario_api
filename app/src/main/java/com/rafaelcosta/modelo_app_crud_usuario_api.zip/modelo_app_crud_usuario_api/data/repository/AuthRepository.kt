package com.rafaelcosta.modelo_app_crud_usuario_api.data.repository

import com.rafaelcosta.modelo_app_crud_usuario_api.data.local.TokenStore
import com.rafaelcosta.modelo_app_crud_usuario_api.data.remote.AuthApiService
import com.rafaelcosta.modelo_app_crud_usuario_api.data.remote.LoginRequest
import com.rafaelcosta.modelo_app_crud_usuario_api.data.remote.RefreshRequest
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor(
    private val authApi: AuthApiService,
    private val store: TokenStore
) {

    suspend fun login(email: String, senha: String): Boolean {
        val resp = authApi.login(LoginRequest(email, senha))
        val access = resp.accessToken
        val refresh = resp.refreshToken
        if (!refresh.isNullOrBlank()) store.saveTokens(access, refresh)
        else store.saveAccessToken(access)
        return access.isNotBlank()
    }

    suspend fun refreshToken(): Boolean {
        val refresh = store.getRefreshToken() ?: return false
        return runCatching {
            val resp = authApi.refresh(RefreshRequest(refresh))
            store.saveAccessToken(resp.accessToken)
            store.saveRefreshToken(resp.refreshToken ?: refresh)
            true
        }.getOrDefault(false)
    }

    suspend fun me() = authApi.me()

    suspend fun logout() = store.clearTokens()

    fun tokenFlow() = store.token
}
