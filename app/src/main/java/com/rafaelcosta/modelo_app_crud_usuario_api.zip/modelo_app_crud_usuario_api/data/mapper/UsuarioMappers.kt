package com.rafaelcosta.modelo_app_crud_usuario_api.data.mapper

import com.rafaelcosta.modelo_app_crud_usuario_api.data.local.entity.UsuarioEntity
import com.rafaelcosta.modelo_app_crud_usuario_api.data.remote.dto.UsuarioDto
import com.rafaelcosta.modelo_app_crud_usuario_api.domain.model.Usuario

fun UsuarioDto.toEntity(pending: Boolean = false) = UsuarioEntity(
    id = id,
    nome = nome,
    email = email,
    cpf = cpf,
    senha = null,
    fotoPerfilUrl = fotoPerfilUrl,
    anexos=anexos,
    updatedAt = updatedAt,
    pendingSync = pending
)

fun UsuarioDto.toDomain() = Usuario(
    id = id,
    nome = nome,
    email = email,
    cpf = cpf,
    senha = senha,
    fotoPerfilUrl = fotoPerfilUrl,
    anexos = anexos ?: emptyList(),
    updatedAt = updatedAt
)

fun UsuarioEntity.toDomain() = Usuario(
    id = id,
    nome = nome,
    email = email,
    cpf = cpf,
    senha = senha,
    fotoPerfilUrl = fotoPerfilUrl,
    anexos = anexos ?: emptyList(),
    updatedAt = updatedAt
)

fun Usuario.toDto() = UsuarioDto(
    id = id,
    nome = nome,
    email = email,
    cpf = cpf,
    senha = senha,
    fotoPerfilUrl = fotoPerfilUrl,
    anexos=anexos ?: emptyList(),
    updatedAt = updatedAt
)

fun Usuario.toEntity(pending: Boolean) = UsuarioEntity(
    id = id,
    nome = nome,
    email = email,
    cpf = cpf,
    senha = senha,
    fotoPerfilUrl = fotoPerfilUrl,
    anexos=anexos,
    updatedAt = updatedAt,
    pendingSync = pending
)