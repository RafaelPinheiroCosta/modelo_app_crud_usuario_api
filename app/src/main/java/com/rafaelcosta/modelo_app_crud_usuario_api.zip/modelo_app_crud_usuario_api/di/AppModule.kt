package com.rafaelcosta.modelo_app_crud_usuario_api.di

import android.content.Context
import com.google.gson.Gson
import com.rafaelcosta.modelo_app_crud_usuario_api.data.local.TokenStore
import com.rafaelcosta.modelo_app_crud_usuario_api.data.remote.AuthApiService
import com.rafaelcosta.modelo_app_crud_usuario_api.data.remote.UsuarioApi
import com.rafaelcosta.modelo_app_crud_usuario_api.data.remote.RefreshRequest
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.Authenticator
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton @Named("baseUrl")
    fun provideBaseUrl(): String = "http://10.83.131.30:8080/"// "http://10.0.2.2:8080/"// "http://192.168.15.183:8080/" //

    @Provides @Singleton
    fun provideLogging(): HttpLoggingInterceptor =
        HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }

    @Provides @Singleton
    fun provideAuthInterceptor(tokenStore: TokenStore): Interceptor = Interceptor { chain ->
        val original: Request = chain.request()
        val token = tokenStore.getAccessTokenSync()
        val req = if (!token.isNullOrBlank()) {
            original.newBuilder()
                .addHeader("Authorization", "Bearer $token")
                .build()
        } else original
        chain.proceed(req)
    }

    @Provides @Singleton
    fun provideTokenAuthenticator(
        tokenStore: TokenStore,
        @Named("auth") authRetrofit: Retrofit
    ): Authenticator = Authenticator { _, response ->
        // evita loop (ex.: já tentou renovar e falhou)
        if (response.request.url.encodedPath.contains("/auth/refresh") ||
            responseCount(response) >= 2
        ) return@Authenticator null

        val refreshToken = tokenStore.getRefreshTokenSync() ?: return@Authenticator null

        val service = authRetrofit.create(AuthApiService::class.java)

        android.util.Log.d("Auth", "Token expirado — tentando refresh...")
        val refreshed = try {
            val resp = service.refreshCall(RefreshRequest(refreshToken)).execute()
            if (resp.isSuccessful) {
                android.util.Log.d("Auth", "Refresh bem-sucedido!")
                resp.body()
            } else {
                android.util.Log.d("Auth", "Falha no refresh: ${resp.code()}")
                null
            }
        } catch (e: Exception) {
            android.util.Log.e("Auth", "Erro no refresh", e)
            null
        }

        val newAccess = refreshed?.accessToken ?: return@Authenticator null

        tokenStore.saveAccessTokenSync(newAccess)
        refreshed.refreshToken?.let { tokenStore.saveRefreshTokenSync(it) }

        response.request.newBuilder()
            .header("Authorization", "Bearer $newAccess")
            .build()
    }

    private fun responseCount(response: Response): Int {
        var count = 1
        var r: Response? = response.priorResponse
        while (r != null) { count++; r = r.priorResponse }
        return count
    }

    @Provides @Singleton @Named("authClient")
    fun provideAuthClient(logging: HttpLoggingInterceptor): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

    @Provides @Singleton @Named("apiClient")
    fun provideApiClient(
        logging: HttpLoggingInterceptor,
        authInterceptor: Interceptor,
        authenticator: Authenticator
    ): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(logging)
            .addInterceptor(authInterceptor)
            .authenticator(authenticator)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    @Provides @Singleton @Named("auth")
    fun provideAuthRetrofit(
        @Named("baseUrl") baseUrl: String,
        @Named("authClient") client: OkHttpClient
    ): Retrofit =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    @Provides @Singleton @Named("api")
    fun provideApiRetrofit(
        @Named("baseUrl") baseUrl: String,
        @Named("apiClient") client: OkHttpClient
    ): Retrofit =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    @Provides @Singleton
    fun provideAuthApiService(@Named("auth") retrofit: Retrofit): AuthApiService =
        retrofit.create(AuthApiService::class.java)

    @Provides @Singleton
    fun provideUsuarioApi(@Named("api") retrofit: Retrofit): UsuarioApi =
        retrofit.create(UsuarioApi::class.java)

    @Provides
    @Singleton
    fun provideTokenStore(@ApplicationContext context: Context): TokenStore =
        TokenStore(context)

    @Provides
    @Singleton
    fun provideGson(): Gson = Gson()
}
