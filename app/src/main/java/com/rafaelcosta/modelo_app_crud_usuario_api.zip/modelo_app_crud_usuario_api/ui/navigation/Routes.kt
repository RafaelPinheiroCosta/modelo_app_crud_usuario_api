package com.rafaelcosta.modelo_app_crud_usuario_api.ui.navigation

object Routes {
    const val Login = "login"
    const val Home = "home"
    const val UsuarioList = "usuarios"
    const val UsuarioForm = "usuario_form"
}